
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ingeo
 */
public class CondiSimple {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite un número ");
        int num= sc.nextInt();
        if (num>10) {
            System.out.println("El numero es mayor que 10");            
        }else{
            System.out.println("El numero es menor o igual que 10");
            System.out.println("Otra linea del Else");
            int x; //declaracion
            x=3;
            System.out.println(x);
        }
        
        
    }
    
}
