
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ingeo
 */
public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Digite la distancia en Kilometros");
        double distancia=sc.nextDouble();
        double distMetros=distancia*1000;
        double distCenti=distMetros*100;
        System.out.println("La distancia en metros es: "+distMetros);
        System.out.println("La distancia en centimetros es: "+distCenti);     
        
    }  
     
    
}
