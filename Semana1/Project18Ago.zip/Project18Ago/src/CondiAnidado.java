
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ingeo
 */
public class CondiAnidado {
    public static void main(String[] args) {
        int num1, num2;
        Scanner sc=new Scanner(System.in);
        System.out.println("Digite un numero");
        num1=sc.nextInt();
        System.out.println("Digite el otro numero");
        num2=sc.nextInt();
        if (num1==num2) {
            System.out.println("Los numeros son iguales");            
        } else if(num1>num2) {
            System.out.println("El primer número es mayor");            
        }else {
            System.out.println("El segundo numero es mayor que el primero");
            int sum= (num1+num2)*2;
            System.out.println(sum);
            
        }       
        
    }
}
