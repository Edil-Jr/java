
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ingeo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Digite su nombre: ");
        String nombre= sc.nextLine();
        System.out.println("Hola "+nombre+" binevenid@");
        System.out.println("Digite su edad");
        int edad=sc.nextInt();
        System.out.println("Su edad aumentada en 2 años es: "+(edad+2));
        System.out.println("Digite su estatura: ");
        double estatura=sc.nextDouble();
        System.out.println("Su estatura disminuida en medio metro es: "+(estatura-0.5));
        
        
        
        
        
        
        
        
        
       
    }
    
}
