/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1g52;

/**
 *
 * @author ingeo
 */
public class Project1G52 {

    /**
     * @param args the command line arguments
     */
    
       
    public static void main(String[] args) {         
        int x=12;
        int y;
        //int z;
        x++;
        ++x;        
        boolean z=24>2;
        System.out.println(z);
        //System.out.println(z);
    }
    
}
