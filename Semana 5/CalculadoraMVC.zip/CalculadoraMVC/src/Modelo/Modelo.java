/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author ingeo
 */
public class Modelo {
    private int valor1;
    private int valor2;
    private int total;

    public Modelo() {
    }
    

    public int getValor1() {
        return valor1;
    }

    public void setValor1(int valor1) {
        this.valor1 = valor1;
    }

    public int getValor2() {
        return valor2;
    }

    public void setValor2(int valor2) {
        this.valor2 = valor2;
    }

    public int getTotal() {
        return total;
    }

    public int sumar(){
        this.total=this.valor1+this.valor2;
        return this.total;    
    }
    
    public int restar(){
        this.total=this.valor1-this.valor2;
        return this.total;    
    }
    
    
    
    
    
}
