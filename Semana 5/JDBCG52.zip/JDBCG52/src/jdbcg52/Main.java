/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcg52;

import java.sql.*;

/**
 *
 * @author ingeo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String url="jdbc:mysql://localhost:3306/erp?serverTimezone=UTC";
        String user="root";
        String password="admin1234";        
        try {
            Connection conn=DriverManager.getConnection(url,user,password);
            
            if (conn != null) {
                System.out.println("Conectado");
                
            } 
            
            /*Insertar
            String sql="INSERT INTO Clientes (Cedula, Nombre, Ciudad, Pais) VALUES (?,?,?,?)";
            PreparedStatement pstm= conn.prepareStatement(sql);
            pstm.setInt(1, 32563);
            pstm.setString(2, "Luis Diaz");
            pstm.setString(3, "Barranca");
            pstm.setString(4, "Colombia");            
            int filasAgregadas=pstm.executeUpdate();
            if (filasAgregadas>0) {
                System.out.println("Inserción Exitosa");
                
            }
            
            */
            
            /*Actualización
            String sql="UPDATE Clientes SET Ciudad=?, Pais=? WHERE cedula=?";
            PreparedStatement pstm= conn.prepareStatement(sql);
            pstm.setString(1, "New York");
            pstm.setString(2, "Estados Unidos");
            pstm.setInt(3, 323);                       
            int filasAgregadas=pstm.executeUpdate();
            if (filasAgregadas>0) {
                System.out.println("ACtualización Exitosa");
                
            }
            */
            
            /* Borrar 
            String sql="DELETE FROM Clientes WHERE Cedula=?";
            PreparedStatement pstm= conn.prepareStatement(sql);            
            pstm.setInt(1, 76232);                       
            int filasAgregadas=pstm.executeUpdate();
            if (filasAgregadas>0) {
                System.out.println("Eliminación Exitosa");
                
            }
            */
            
            String sql="SELECT * FROM Clientes";
            Statement stm=conn.createStatement();
            ResultSet rs=stm.executeQuery(sql);
            while (rs.next()) {
                int cedula=rs.getInt("cedula");
                String nombre=rs.getString("nombre");
                String ciudad=rs.getString("ciudad");
                String pais=rs.getString("pais");
                System.out.println(cedula+","+nombre+","+ciudad+","+pais);
                
                
                
            }
            
            
            
        } catch (SQLException e) {
            e.printStackTrace();
            
        }
        
        
        
    }
    
}
